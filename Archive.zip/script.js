const takePhotoBtn = document.getElementById("takePhotoBtn");
const MAX_PHOTOS = 50; // Maximum number of photos

// Accessing camera
navigator.mediaDevices
  .getUserMedia({ video: true })
  .then((stream) => {
    const video = document.createElement("video");
    video.srcObject = stream;
    video.play();
    document.getElementById("cameraView").appendChild(video);
  })
  .catch((error) => console.error("Error accessing camera:", error));

takePhotoBtn.addEventListener("click", () => {
  const photoDataURL = capturePhoto();
  savePhotoToLocalStorage(photoDataURL);
});

document.body.onkeyup = function (e) {
  if (e.key === " " || e.code === "Space" || e.keyCode === 32) {
    const photoDataURL = capturePhoto();
    savePhotoToLocalStorage(photoDataURL);
  }
};

function capturePhoto() {
  const canvas = document.createElement("canvas");
  const context = canvas.getContext("2d");
  const video = document.querySelector("video");

  canvas.width = 320; // Smaller width
  canvas.height = 240; // Smaller height
  context.drawImage(video, 0, 0, canvas.width, canvas.height);

  return canvas.toDataURL("image/png");
}

function savePhotoToLocalStorage(photoDataURL) {
  let photos = JSON.parse(localStorage.getItem("capturedPhotos")) || [];
  if (photos.length >= MAX_PHOTOS) {
    alert("Maximum number of photos reached. Please download and reset the photos from the second screen.");
  } else {
    photos.push(photoDataURL);
    localStorage.setItem("capturedPhotos", JSON.stringify(photos));
  }
}

function onReloadPage() {
  localStorage.removeItem("capturedPhotos");
}
